""""import cv2
import os
import time
import threading
import insightface
import numpy as np

# ======================================
# SETTINGS
# ======================================
SAVE_FOLDER = "Entries"

# Increase images
IMAGES_PER_PERSON = int(input("Enter the number of images to be captured: "))
print(IMAGES_PER_PERSON)

# Faster save interval
SAVE_INTERVAL = 0.08

# Detection interval
DETECT_INTERVAL = 0.03

# Camera size (lower = lower latency)
CAM_W = 640
CAM_H = 480

# ======================================
# CREATE FOLDER
# ======================================
os.makedirs(SAVE_FOLDER, exist_ok=True)

name = input("Enter Name: ").strip().title()

folder = os.path.join(SAVE_FOLDER, name)

if os.path.exists(folder):
    print("Already Registered")
    quit()

os.makedirs(folder)

# ======================================
# MODEL
# ======================================
app = insightface.app.FaceAnalysis(model="buffalo_l")
app.prepare(ctx_id=-1, det_size=(96,96))   # smaller = faster

# ======================================
# SHARED MEMORY
# ======================================
latest_frame = None
face_box = None
running = True
count = 0

lock = threading.Lock()

# angle tracker
captured_angles = set()

# ======================================
# CAMERA THREAD (LOW LATENCY PATCH)
# ======================================
def camera_thread():

    global latest_frame

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    # ultra low latency patches
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAM_W)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAM_H)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    cap.set(cv2.CAP_PROP_FPS, 60)

    while running:

        # flush old frames patch
        cap.grab()
        ret, frame = cap.read()

        if ret:
            with lock:
                latest_frame = frame.copy()

    cap.release()

# ======================================
# DETECTION THREAD
# ======================================
def detect_thread():

    global face_box

    while running:

        if latest_frame is None:
            continue

        with lock:
            frame = latest_frame.copy()

        # smaller image patch for faster detect
        small = cv2.resize(frame, (320,240))

        faces = app.get(small)

        if len(faces) > 0:

            x1,y1,x2,y2 = faces[0].bbox.astype(int)

            # scale back
            x1 = int(x1 * 2)
            y1 = int(y1 * 2)
            x2 = int(x2 * 2)
            y2 = int(y2 * 2)

            with lock:
                face_box = (x1,y1,x2,y2)

        else:
            with lock:
                face_box = None

        time.sleep(DETECT_INTERVAL)

# ======================================
# SAVE THREAD
# ======================================
def save_thread():

    global count

    while running:

        if latest_frame is None or face_box is None:
            time.sleep(0.01)
            continue

        if count >= IMAGES_PER_PERSON:
            break

        with lock:
            frame = latest_frame.copy()
            x1,y1,x2,y2 = face_box

        crop = frame[max(0,y1):y2, max(0,x1):x2]

        if crop.size == 0:
            continue

        # -----------------------------------
        # ANGLE ESTIMATION PATCH
        # -----------------------------------
        w = x2 - x1
        h = y2 - y1

        ratio = w / h

        if ratio < 0.75:
            angle = "left/right"
        elif ratio > 0.95:
            angle = "front"
        else:
            angle = "slight"

        # save only diverse angles repeatedly
        filename = f"{count}_{angle}.jpg"

        cv2.imwrite(
            os.path.join(folder, filename),
            crop
        )

        count += 1
        print("Saved", count, angle)

        # -----------------------------------
        # DATA AUGMENT PATCH
        # -----------------------------------
        if count < IMAGES_PER_PERSON:

            flip = cv2.flip(crop,1)

            cv2.imwrite(
                os.path.join(folder, f"{count}_flip.jpg"),
                flip
            )

            count += 1
            print("Saved", count, "flip")

        time.sleep(SAVE_INTERVAL)

# ======================================
# START THREADS
# ======================================
threading.Thread(target=camera_thread, daemon=True).start()
threading.Thread(target=detect_thread, daemon=True).start()
threading.Thread(target=save_thread, daemon=True).start()

# ======================================
# WINDOW
# ======================================
cv2.namedWindow("Ultra Fast Registration", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Ultra Fast Registration", 900,700)

# ======================================
# MAIN LOOP
# ======================================
while True:

    if latest_frame is None:
        continue

    with lock:
        frame = latest_frame.copy()
        box = face_box

    if box is not None:

        x1,y1,x2,y2 = box

        cv2.rectangle(
            frame,
            (x1,y1),
            (x2,y2),
            (0,255,0),
            2
        )

    cv2.putText(
        frame,
        f"{name} {count}/{IMAGES_PER_PERSON}",
        (20,40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0,255,0),
        2
    )

    cv2.putText(
        frame,
        "Move Face Left Right Up Down",
        (20,80),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0,255,255),
        2
    )

    cv2.imshow("Ultra Fast Registration", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

    if count >= IMAGES_PER_PERSON:
        break

running = False
cv2.destroyAllWindows()

print(name, "Registered Successfully")"""

# ==========================================
# recognize.py
# First user OR new user registration
# Creates faces.pkl if missing
# Adds only new person later
# ==========================================

import cv2
import os
import time
import pickle
import threading
import numpy as np
import insightface

ROOT = "Entries"
DB_FILE = "faces.pkl"

TARGET = 12
SAVE_INTERVAL = 0.05
MIN_MOVE = 12

os.makedirs(ROOT, exist_ok=True)

# ------------------------------------------
# LOAD / CREATE EMPTY DATABASE
# ------------------------------------------
if os.path.exists(DB_FILE):

    with open(DB_FILE, "rb") as f:
        data = pickle.load(f)

    known_embeddings = list(data["embeddings"])
    known_names = list(data["names"])

    print("Loaded existing database")

else:

    known_embeddings = []
    known_names = []

    print("No database found")
    print("Starting first registration")

# ------------------------------------------
# INPUT
# ------------------------------------------
name = input("Enter Name: ").strip().title()

if name == "":
    quit()

if name in known_names:
    print("Name already exists")
    quit()

person_folder = os.path.join(ROOT, name)
os.makedirs(person_folder, exist_ok=True)

# ------------------------------------------
# MODEL
# ------------------------------------------
app = insightface.app.FaceAnalysis(name="buffalo_s")
app.prepare(ctx_id=-1, det_size=(96,96))

latest_frame = None
face_box = None
running = True
count = 0

lock = threading.Lock()

# ------------------------------------------
# CAMERA
# ------------------------------------------
def cam():

    global latest_frame

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
    cap.set(cv2.CAP_PROP_BUFFERSIZE,1)
    cap.set(cv2.CAP_PROP_FPS,30)

    while running:

        cap.grab()
        ret, frame = cap.read()

        if ret:
            with lock:
                latest_frame = frame.copy()

    cap.release()

# ------------------------------------------
# REGISTER
# ------------------------------------------
def reg():

    global count, face_box

    last_save = 0
    last_center = None
    embs = []

    while running:

        if latest_frame is None:
            time.sleep(0.002)
            continue

        if count >= TARGET:
            break

        now = time.time()

        if now - last_save < SAVE_INTERVAL:
            continue

        with lock:
            frame = latest_frame.copy()

        small = cv2.resize(frame,(320,240))

        faces = app.get(small)

        if len(faces) == 0:
            continue

        best = max(
            faces,
            key=lambda f:
            (f.bbox[2]-f.bbox[0]) *
            (f.bbox[3]-f.bbox[1])
        )

        x1,y1,x2,y2 = best.bbox.astype(int)

        x1*=2; y1*=2; x2*=2; y2*=2

        w = x2-x1
        h = y2-y1

        cx = x1 + w//2
        cy = y1 + h//2

        if last_center is not None:

            dist = np.sqrt(
                (cx-last_center[0])**2 +
                (cy-last_center[1])**2
            )

            if dist < MIN_MOVE:
                with lock:
                    face_box = (x1,y1,w,h)
                continue

        crop = frame[y1:y2, x1:x2]

        if crop.size == 0:
            continue

        embs.append(best.normed_embedding)

        cv2.imwrite(
            os.path.join(
                person_folder,
                f"{count+1}.jpg"
            ),
            crop
        )

        with lock:
            face_box = (x1,y1,w,h)

        count += 1
        last_save = now
        last_center = (cx,cy)

    # SAVE NEW PERSON
    if len(embs) > 0:

        mean_emb = np.mean(embs, axis=0)
        mean_emb = mean_emb / np.linalg.norm(mean_emb)

        known_embeddings.append(mean_emb)
        known_names.append(name)

        data = {
            "embeddings": np.array(known_embeddings),
            "names": known_names
        }

        with open(DB_FILE, "wb") as f:
            pickle.dump(data, f)

        print("Added:", name)

threading.Thread(target=cam,daemon=True).start()
threading.Thread(target=reg,daemon=True).start()

cv2.namedWindow("Register",cv2.WINDOW_NORMAL)
cv2.resizeWindow("Register",900,700)

while True:

    if latest_frame is None:
        continue

    with lock:
        frame = latest_frame.copy()
        box = face_box

    if box is not None:

        x,y,w,h = box

        cv2.rectangle(
            frame,
            (x,y),
            (x+w,y+h),
            (0,255,0),
            2
        )

    cv2.putText(
        frame,
        f"{name} {count}/{TARGET}",
        (20,40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0,255,0),
        2
    )

    cv2.imshow("Register",frame)

    if cv2.waitKey(1)&0xFF==ord("q"):
        break

    if count >= TARGET:
        break

running = False
cv2.destroyAllWindows()

