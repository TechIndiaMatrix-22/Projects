"""import cv2
import os
import pickle
import numpy as np
import insightface

SAVE_FOLDER = "Entries"

# -----------------------------------
# USER ENTERS ANY NAME
# -----------------------------------
db_name = input("Enter new database name: ").strip()

if db_name == "":
    print("Invalid name")
    quit()

# Auto add .pkl
db_file = db_name + ".pkl"

# -----------------------------------
# LOAD MODEL
# -----------------------------------
app = insightface.app.FaceAnalysis(model="buffalo_l")
app.prepare(ctx_id=-1, det_size=(128,128))

known_embeddings = []
known_names = []

# -----------------------------------
# READ FOLDERS
# -----------------------------------
for person in os.listdir(SAVE_FOLDER):

    folder = os.path.join(SAVE_FOLDER, person)

    if not os.path.isdir(folder):
        continue

    for file in os.listdir(folder):

        path = os.path.join(folder, file)

        img = cv2.imread(path)

        if img is None:
            continue

        faces = app.get(img)

        if len(faces) > 0:

            known_embeddings.append(faces[0].normed_embedding)
            known_names.append(person)

# -----------------------------------
# SAVE DATABASE
# -----------------------------------
data = {
    "embeddings": np.array(known_embeddings),
    "names": known_names
}

with open(db_file, "wb") as f:
    pickle.dump(data, f)

print("Training Completed")
print("Saved as:", db_file)"""

# ==========================================
# train.py
# Use only if you already have folders in Entries/
# Builds fresh faces.pkl from saved images
# ==========================================

import os
import cv2
import pickle
import numpy as np
import insightface

ROOT = "Entries"
DB_FILE = "faces.pkl"

os.makedirs(ROOT, exist_ok=True)

app = insightface.app.FaceAnalysis(name="buffalo_s")
app.prepare(ctx_id=-1, det_size=(96,96))

embeddings = []
names = []

for person in os.listdir(ROOT):

    folder = os.path.join(ROOT, person)

    if not os.path.isdir(folder):
        continue

    person_embs = []

    for file in os.listdir(folder):

        path = os.path.join(folder, file)

        img = cv2.imread(path)

        if img is None:
            continue

        faces = app.get(img)

        if len(faces) == 0:
            continue

        emb = faces[0].normed_embedding
        person_embs.append(emb)

    if len(person_embs) > 0:

        mean_emb = np.mean(person_embs, axis=0)
        mean_emb = mean_emb / np.linalg.norm(mean_emb)

        embeddings.append(mean_emb)
        names.append(person)

        print("Added:", person)

data = {
    "embeddings": np.array(embeddings),
    "names": names
}

with open(DB_FILE, "wb") as f:
    pickle.dump(data, f)

print("Created:", DB_FILE)