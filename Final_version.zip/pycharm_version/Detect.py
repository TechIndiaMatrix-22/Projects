"""import cv2
import os
import pickle
import numpy as np
import insightface

# ==================================================
# SETTINGS
# ==================================================
MATCH_THRESHOLD = 0.45

# ==================================================
# ASK DATABASE NAME
# ==================================================
db_name = input("Enter database name to load: ").strip()

if db_name == "":
    print("Invalid name")
    quit()

db_file = db_name + ".pkl"

# ==================================================
# CHECK FILE EXISTS
# ==================================================
if not os.path.exists(db_file):

    print(db_file, "not found.")
    quit()

# ==================================================
# LOAD DATABASE
# ==================================================
with open(db_file, "rb") as f:
    data = pickle.load(f)

known_embeddings = data["embeddings"]
known_names = data["names"]

print("Loaded:", db_file)

# ==================================================
# LOAD MODEL
# ==================================================
app = insightface.app.FaceAnalysis(name="buffalo_s")
app.prepare(ctx_id=-1, det_size=(128,128))

# CAMERA
# ==================================================
cap = cv2.VideoCapture(0)

# Create popup window first
cv2.namedWindow("Face Detection", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Face Detection", 900, 700)
cv2.moveWindow("Face Detection", 100, 50)

print("Detection Started")
print("Press Q to Quit")

# ==================================================
# LOOP
# ==================================================
while True:

    ret, frame = cap.read()

    if not ret:
        continue

    faces = app.get(frame)

    for face in faces:

        x1, y1, x2, y2 = face.bbox.astype(int)

        emb = face.normed_embedding

        sims = np.dot(known_embeddings, emb)

        best = np.argmax(sims)

        score = float(sims[best])

        if score > MATCH_THRESHOLD:
            name = known_names[best]
        else:
            name = "Unknown"

        similarity = int(score * 100)

        color = (0,255,0) if name != "Unknown" else (0,0,255)

        cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)

        cv2.putText(frame,
                    f"{name} Similar {similarity}%",
                    (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    color,
                    2)

    cv2.imshow("Face Detection", frame)

    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break

# ==================================================
# CLOSE
# ==================================================
cap.release()
cv2.destroyAllWindows()"""

# ==========================================================
# detect.py
# ULTRA LOW LATENCY FACE SYSTEM
# Rebuilt architecture for speed + smoothness
# ==========================================================

import cv2
import os
import time
import pickle
import threading
import numpy as np
import insightface

# ==========================================================
# SETTINGS
# ==========================================================
DB_FILE = "faces.pkl"
MATCH_THRESHOLD = 0.42

CAM_W = 640
CAM_H = 480

DETECT_W = 256
DETECT_H = 192

RECOG_INTERVAL = 0.30

# ==========================================================
# DATABASE
# ==========================================================
if not os.path.exists(DB_FILE):
    print("No database found")
    print("Run recognize.py first")
    quit()

with open(DB_FILE, "rb") as f:
    data = pickle.load(f)

known_embeddings = np.array(
    data["embeddings"],
    dtype=np.float32
)

known_names = data["names"]

print("Loaded:", DB_FILE)

# ==========================================================
# MODEL
# buffalo_s fastest practical option
# ==========================================================
app = insightface.app.FaceAnalysis(name="buffalo_s")
app.prepare(ctx_id=-1, det_size=(96,96))

# ==========================================================
# SHARED MEMORY
# ==========================================================
latest_frame = None
face_box = None
face_name = "Unknown"
face_similarity = 0
running = True

lock = threading.Lock()

# ==========================================================
# CAMERA THREAD
# latest frame only / zero queue feel
# ==========================================================
def cam():

    global latest_frame

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAM_W)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAM_H)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    cap.set(cv2.CAP_PROP_FPS, 30)

    while running:

        cap.grab()
        ret, frame = cap.read()

        if ret:
            with lock:
                latest_frame = frame

    cap.release()

# ==========================================================
# DETECTION THREAD
# dedicated fast box updates
# ==========================================================
def detect():

    global face_box

    smooth_box = None
    last_seen = time.time()

    alpha = 0.68

    while running:

        if latest_frame is None:
            time.sleep(0.001)
            continue

        with lock:
            frame = latest_frame.copy()

        # smaller image
        small = cv2.resize(
            frame,
            (DETECT_W, DETECT_H),
            interpolation=cv2.INTER_LINEAR
        )

        faces = app.get(small)

        if len(faces) > 0:

            best = max(
                faces,
                key=lambda f:
                (f.bbox[2]-f.bbox[0]) *
                (f.bbox[3]-f.bbox[1])
            )

            x1,y1,x2,y2 = best.bbox.astype(int)

            sx = CAM_W / DETECT_W
            sy = CAM_H / DETECT_H

            x1 = int(x1 * sx)
            y1 = int(y1 * sy)
            x2 = int(x2 * sx)
            y2 = int(y2 * sy)

            w = x2 - x1
            h = y2 - y1

            new_box = np.array(
                [x1,y1,w,h],
                dtype=np.float32
            )

            if smooth_box is None:
                smooth_box = new_box
            else:
                smooth_box = (
                    alpha * new_box +
                    (1-alpha) * smooth_box
                )

            with lock:
                face_box = tuple(
                    smooth_box.astype(int)
                )

            last_seen = time.time()

        else:

            if time.time() - last_seen > 0.08:
                with lock:
                    face_box = None
                smooth_box = None

        time.sleep(0.001)

# ==========================================================
# RECOGNITION THREAD
# slower than detector intentionally
# ==========================================================
def recog():

    global face_name, face_similarity

    while running:

        if latest_frame is None or face_box is None:
            time.sleep(0.03)
            continue

        with lock:
            frame = latest_frame.copy()
            box = face_box

        x,y,w,h = box

        x = max(0,x)
        y = max(0,y)
        w = max(1,w)
        h = max(1,h)

        crop = frame[y:y+h, x:x+w]

        if crop.size == 0:
            time.sleep(0.03)
            continue

        result = app.get(crop)

        if len(result) > 0:

            emb = result[0].normed_embedding.astype(np.float32)

            sims = np.dot(
                known_embeddings,
                emb
            )

            best = int(np.argmax(sims))
            score = float(sims[best])

            if score > MATCH_THRESHOLD:
                face_name = known_names[best]
            else:
                face_name = "Unknown"

            face_similarity = int(score * 100)

        time.sleep(RECOG_INTERVAL)

# ==========================================================
# START THREADS
# ==========================================================
threading.Thread(target=cam, daemon=True).start()
threading.Thread(target=detect, daemon=True).start()
threading.Thread(target=recog, daemon=True).start()

# ==========================================================
# WINDOW
# ==========================================================
cv2.namedWindow("Ultra Detect", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Ultra Detect", 900,700)

# ==========================================================
# MAIN LOOP
# ==========================================================
while True:

    if latest_frame is None:
        continue

    with lock:
        frame = latest_frame.copy()
        box = face_box
        name = face_name
        sim = face_similarity

    if box is not None:

        x,y,w,h = box

        color = (0,255,0) if name != "Unknown" else (0,0,255)

        cv2.rectangle(
            frame,
            (x,y),
            (x+w,y+h),
            color,
            2
        )

        cv2.putText(
            frame,
            name,
            (x, y-25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            color,
            2
        )

        cv2.putText(
            frame,
            f"{sim}%",
            (x, y-5),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            color,
            2
        )

    cv2.imshow("Ultra Detect", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

running = False
cv2.destroyAllWindows()