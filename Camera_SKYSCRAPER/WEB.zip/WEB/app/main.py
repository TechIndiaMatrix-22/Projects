from __future__ import annotations
import hashlib, hmac, os, re, secrets, shutil, sqlite3, subprocess, threading, time, signal, json, urllib.request, urllib.error
from datetime import datetime, timezone
from pathlib import Path
from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.templating import Jinja2Templates
from argon2 import PasswordHasher, exceptions as argon2_exceptions

BASE = Path(__file__).resolve().parent.parent
WEB = BASE / "web"
MOUNT = Path(os.getenv("SKYSCRAPER_MOUNT", "/media/camera_sd"))
MEDIA = Path(os.getenv("SKYSCRAPER_MEDIA", str(MOUNT)))
IMAGE_DIR, VIDEO_DIR = MEDIA / "Images", MEDIA / "Videos"
DB = Path(os.getenv("SKYSCRAPER_DB", str(Path.home()/".local/share/skyscraper/skyscraper.db")))
SECRET = os.getenv("SKYSCRAPER_SECRET")
EXPECTED_UUID = os.getenv("SKYSCRAPER_SD_UUID", "").strip().lower()
TOKEN_TTL_SECONDS = 600
password_hasher = PasswordHasher()
if not SECRET:
    raise RuntimeError("SKYSCRAPER_SECRET is missing. Run setup.sh first.")

app = FastAPI(title="SKYSCRAPER", version="2.0.0")
app.add_middleware(SessionMiddleware, secret_key=SECRET, same_site="lax", https_only=False, max_age=43200)
app.mount("/static", StaticFiles(directory=WEB), name="static")
templates = Jinja2Templates(directory=WEB)

# MediaMTX configuration. These can be overridden in /etc/skyscraper.env.
MEDIAMTX_BIN = Path(os.getenv("SKYSCRAPER_MEDIAMTX_BIN",
    str(Path.home() / "Desktop/Projects/Night_vision/mediamtx")))
MEDIAMTX_CONFIG = Path(os.getenv("SKYSCRAPER_MEDIAMTX_CONFIG",
    str(Path.home() / "Desktop/Projects/Night_vision/mediamtx.yml")))
MEDIAMTX_API = os.getenv("SKYSCRAPER_MEDIAMTX_API", "http://127.0.0.1:9997")
MEDIAMTX_WEBRTC_PORT = int(os.getenv("SKYSCRAPER_WEBRTC_PORT", "8889"))
MEDIAMTX_PATH = os.getenv("SKYSCRAPER_MEDIAMTX_PATH", "cam1")

mediamtx_lock = threading.RLock()
mediamtx_process = None
recording_lock = threading.RLock()
recording = {"active": False, "processes": [], "files": [], "file": None, "cameras": []}
tokens_lock = threading.Lock()
one_time_tokens = {}

camera_status_lock = threading.Lock()
camera_status_cache = {
    "detected": False,
    "status": "INITIALIZING",
    "name": None,
    "raw_output": "Camera inventory has not been collected yet.",
    "sensors": [],
    "checked_at": None,
}

# VLC-style settings (milliseconds except the clock options).
DEFAULT_ADVANCED = {
    "file_cache_ms": 1000,
    "live_capture_cache_ms": 300,
    "disc_cache_ms": 300,
    "network_cache_ms": 35,
    "clock_average_counter": 40,
    "clock_sync": "Default",
    "clock_jitter_ms": 5000,
}
SETTINGS_FILE = Path(os.getenv("SKYSCRAPER_SETTINGS_FILE",
    str(Path.home()/".config/skyscraper/advanced_settings.json")))
SETTINGS_LOCK = threading.Lock()
CLOCK_SYNC_OPTIONS = ["Default", "Audio", "Video", "External"]

def load_advanced_settings():
    with SETTINGS_LOCK:
        try:
            raw = json.loads(SETTINGS_FILE.read_text())
            data = DEFAULT_ADVANCED.copy()
            data.update(raw if isinstance(raw, dict) else {})
        except (OSError, ValueError):
            data = DEFAULT_ADVANCED.copy()
        return data

def save_advanced_settings(data):
    # Strict validation: only settings displayed by dashboard are accepted.
    limits = {
        "file_cache_ms": (0, 10000), "live_capture_cache_ms": (0, 10000),
        "disc_cache_ms": (0, 10000), "network_cache_ms": (0, 5000),
        "clock_average_counter": (1, 1000), "clock_jitter_ms": (0, 100000),
    }
    clean = DEFAULT_ADVANCED.copy()
    for key, (lo, hi) in limits.items():
        try: value = int(data.get(key, clean[key]))
        except (TypeError, ValueError): raise HTTPException(400, f"Invalid {key}.")
        if not lo <= value <= hi: raise HTTPException(400, f"{key} must be between {lo} and {hi}.")
        clean[key] = value
    sync = str(data.get("clock_sync", "Default"))
    if sync not in CLOCK_SYNC_OPTIONS: raise HTTPException(400, "Invalid clock synchronization option.")
    clean["clock_sync"] = sync
    with SETTINGS_LOCK:
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        temp = SETTINGS_FILE.with_suffix(".tmp")
        temp.write_text(json.dumps(clean, indent=2))
        temp.replace(SETTINGS_FILE)
    return clean

def run_cmd(args, timeout=5):
    try:
        return subprocess.run(
            args, capture_output=True, text=True, timeout=timeout
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def detect_camera():
    cmd = shutil.which("rpicam-hello") or shutil.which("libcamera-hello")
    checked_at = datetime.now().astimezone().isoformat(timespec="seconds")

    if not cmd:
        return {
            "detected": False,
            "status": "TOOL NOT INSTALLED",
            "name": None,
            "raw_output": "Neither rpicam-hello nor libcamera-hello was found.",
            "sensors": [],
            "checked_at": checked_at,
        }

    try:
        r = subprocess.run(
            [cmd, "--list-cameras"],
            capture_output=True,
            text=True,
            timeout=8,
        )

        output = (r.stdout or "") + (r.stderr or "")
        lower_output = output.lower()

        sensors = [
            line.strip()
            for line in output.splitlines()
            if line.strip() and re.search(
                r"ov\d+|imx\d+|camera\s*\d+|sensor",
                line,
                re.I,
            )
        ]

        detected = r.returncode == 0 and "ov5647" in lower_output

        if detected:
            status = "CONNECTED"
            name = "OV5647"
        else:
            status = "DISCONNECTED" if r.returncode == 0 else "DETECTION ERROR"
            name = None

        return {
            "detected": detected,
            "status": status,
            "name": name,
            "raw_output": output.strip() or "(Camera tool returned no output.)",
            "sensors": sensors,
            "checked_at": checked_at,
        }

    except subprocess.TimeoutExpired:
        return {
            "detected": False,
            "status": "DETECTION TIMEOUT",
            "name": None,
            "raw_output": "Camera detection timed out after 8 seconds.",
            "sensors": [],
            "checked_at": checked_at,
        }

    except Exception as exc:
        return {
            "detected": False,
            "status": "DETECTION ERROR",
            "name": None,
            "raw_output": f"Camera detection error: {exc}",
            "sensors": [],
            "checked_at": checked_at,
        }


def camera_monitor():
    global camera_status_cache
    while True:
        with camera_status_lock: camera_status_cache = detect_camera()
        time.sleep(15)  # avoid repeatedly probing CSI while MediaMTX is using it

def mount_info():
    r = run_cmd(["findmnt", "-rn", "-M", str(MOUNT), "-o", "SOURCE,FSTYPE,UUID"], 3)
    if not r or r.returncode or not r.stdout.strip():
        return {"present": False, "mounted": False, "message": "SD CARD NOT DETECTED", "source": None, "uuid": None, "filesystem": None}
    p = r.stdout.strip().split()
    source, fs, uuid = (p + ["", "", ""])[:3]
    if source.startswith("/dev/"):
        dev = Path(source)
        sys_size = Path("/sys/class/block") / dev.name / "size"
        try:
            if not dev.exists() or int(sys_size.read_text().strip()) == 0:
                return {"present": False, "mounted": False, "message": "SD CARD REMOVED", "source": source, "uuid": uuid, "filesystem": fs}
        except (OSError, ValueError):
            return {"present": False, "mounted": False, "message": "SD CARD UNAVAILABLE", "source": source, "uuid": uuid, "filesystem": fs}
    if EXPECTED_UUID and uuid.lower() != EXPECTED_UUID:
        return {"present": True, "mounted": False, "message": "UNEXPECTED SD CARD", "source": source, "uuid": uuid, "filesystem": fs}
    try: usage = shutil.disk_usage(MOUNT)
    except OSError: return {"present": False, "mounted": False, "message": "SD CARD UNAVAILABLE", "source": source, "uuid": uuid, "filesystem": fs}
    return {"present": True, "mounted": True, "message": "SD CARD CONNECTED", "source": source, "uuid": uuid,
            "filesystem": fs, "total": usage.total, "used": usage.used, "free": usage.free,
            "percent": round(usage.used/usage.total*100, 1) if usage.total else 0}

def require_storage():
    s = mount_info()
    if not s["mounted"]: raise HTTPException(503, s["message"] + "; media functions are disabled.")
    return s

def db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY, salt BLOB, password_hash BLOB NOT NULL, created_at TEXT NOT NULL)""")
    cols = {r["name"] for r in con.execute("PRAGMA table_info(users)")}
    if "salt" not in cols: con.execute("ALTER TABLE users ADD COLUMN salt BLOB")
    if "phone_e164" not in cols: con.execute("ALTER TABLE users ADD COLUMN phone_e164 TEXT")
    con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_phone_e164 ON users(phone_e164) WHERE phone_e164 IS NOT NULL")
    con.commit()
    return con

def password_digest(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)

def current_user(request: Request):
    user = request.session.get("user")
    if not user: raise HTTPException(401, "Please sign in.")
    return user


# SKYSCRAPER owner account
OWNER_USERNAME = "yash"

def require_owner(user=Depends(current_user)):
    if user != OWNER_USERNAME:
        raise HTTPException(403, "Owner permission required.")
    return user


@app.get("/api/admin/deletion-event")
def admin_deletion_event(request: Request, user=Depends(current_user)):
    con = db()
    try:
        con.execute("""
            CREATE TABLE IF NOT EXISTS dashboard_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                username TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        event = con.execute(
            "SELECT id, username FROM dashboard_events "
            "WHERE event_type = 'user_deleted' ORDER BY id LIMIT 1"
        ).fetchone()

        if event is None:
            return {"redirect": None}

        con.execute(
            "DELETE FROM dashboard_events WHERE id = ?",
            (event["id"],)
        )
        con.commit()

        request.session.clear()

        return {
            "redirect": "/?register=1",
            "message": "Account deletion detected."
        }
    finally:
        con.close()


@app.get("/api/users")
def list_users(user=Depends(require_owner)):
    con = db()
    try:
        rows = con.execute(
            "SELECT username, created_at FROM users ORDER BY created_at"
        ).fetchall()
        return [
            {
                "username": row["username"],
                "created_at": row["created_at"],
                "is_owner": row["username"] == OWNER_USERNAME
            }
            for row in rows
        ]
    finally:
        con.close()


@app.delete("/api/users/{username}")
def delete_user(
    username: str,
    request: Request,
    user=Depends(require_owner)
):
    username = username.strip()

    if username == OWNER_USERNAME:
        raise HTTPException(403, "The owner account cannot be deleted.")

    con = db()
    try:
        cursor = con.execute(
            "DELETE FROM users WHERE username = ?",
            (username,)
        )
        con.commit()

        if cursor.rowcount == 0:
            raise HTTPException(404, "User not found.")

        request.session.clear()

        return {
            "ok": True,
            "message": f"User '{username}' deleted.",
            "redirect": "/?register=1"
        }
    finally:
        con.close()


def safe_child(folder, name):
    if Path(name).name != name or name in ("", ".", ".."): raise HTTPException(400, "Invalid filename.")
    return folder / name

def mediamtx_running():
    global mediamtx_process

    with mediamtx_lock:
        mediamtx_process = None

        result = subprocess.run(
            ["sudo", "-n", "systemctl", "is-active", "--quiet", "mediamtx"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

        return result.returncode == 0

def start_mediamtx():
    global mediamtx_process

    with mediamtx_lock:
        mediamtx_process = None

        result = subprocess.run(
            ["sudo", "-n", "systemctl", "start", "mediamtx"],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip()
            raise HTTPException(
                503,
                f"Could not start MediaMTX systemd service: {detail}"
            )

        if not mediamtx_running():
            raise HTTPException(
                503,
                "MediaMTX systemd service did not become active."
            )

        return {"running": True, "message": "MediaMTX started by systemd."}


def stop_mediamtx():
    global mediamtx_process

    with mediamtx_lock:
        mediamtx_process = None

        result = subprocess.run(
            ["sudo", "-n", "systemctl", "stop", "mediamtx"],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip()
            raise HTTPException(
                503,
                f"Could not stop MediaMTX systemd service: {detail}"
            )

        return {"running": False, "message": "MediaMTX stopped by systemd."}


def stop_recording(interrupted=False):
    with recording_lock:
        if not recording["active"]:
            return None
        processes = list(recording.get("processes", []))
        names = list(recording.get("files", []))

    for proc in processes:
        if proc and proc.poll() is None:
            # SIGINT asks FFmpeg to finalize MP4 metadata before exiting.
            proc.send_signal(signal.SIGINT)
            try:
                proc.wait(timeout=12)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()

    with recording_lock:
        recording.update(
            active=False, processes=[], files=[], file=None, cameras=[]
        )

    return {
        "file": ", ".join(names) if names else None,
        "files": names,
        "interrupted": interrupted,
    }

def storage_watchdog():
    while True:
        time.sleep(2)
        if not mount_info()["mounted"]: stop_recording(interrupted=True)

@app.on_event("startup")
def startup():
    db().close()
    threading.Thread(target=storage_watchdog, daemon=True, name="storage-watchdog").start()
    threading.Thread(target=camera_monitor, daemon=True, name="camera-monitor").start()

@app.get("/sw.js", include_in_schema=False)
def service_worker():
    return FileResponse(WEB / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/"})

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    if request.session.get("user"): return RedirectResponse("/dashboard", status_code=303)
    return templates.TemplateResponse(request=request, name="index.html", context={})

def normalize_phone_e164(country_code: str, phone: str) -> str:
    # Store digits only, including country calling code. MSG91 returns identifiers
    # in digits-only international format (for example 919876543210).
    cc = re.sub(r"\D", "", country_code or "")
    number = re.sub(r"\D", "", phone or "")
    if not cc or not number:
        raise HTTPException(400, "Enter a country code and mobile number.")
    if number.startswith(cc):
        normalized = number
    else:
        normalized = cc + number.lstrip("0")
    if not 8 <= len(normalized) <= 15:
        raise HTTPException(400, "Enter a valid international mobile number.")
    return normalized


@app.post("/api/register")
def register(username: str = Form(...), password: str = Form(...),
             country_code: str = Form(...), phone: str = Form(...)):
    username = username.strip()
    if len(username) < 3 or len(password) < 10:
        raise HTTPException(400, "Username must be at least 3 characters and password at least 10.")
    phone_e164 = normalize_phone_e164(country_code, phone)
    con = db()
    try:
        salt = secrets.token_bytes(16)
        con.execute("INSERT INTO users(username,salt,password_hash,created_at,phone_e164) VALUES(?,?,?,?,?)",
            (username, salt, password_digest(password, salt), datetime.now(timezone.utc).isoformat(), phone_e164))
        con.commit()
    except sqlite3.IntegrityError: raise HTTPException(409, "Username already exists.")
    finally: con.close()
    return {"ok": True, "message": "Account created. Please sign in."}

@app.post("/api/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    con = db()
    try:
        row = con.execute("SELECT salt,password_hash FROM users WHERE username=?", (username.strip(),)).fetchone()
        if not row: raise HTTPException(401, "Invalid username or password.")
        stored_hash, salt = row["password_hash"], row["salt"]
        if salt is None:
            try: valid = password_hasher.verify(str(stored_hash), password)
            except (argon2_exceptions.VerificationError, argon2_exceptions.InvalidHashError): valid = False
            if not valid: raise HTTPException(401, "Invalid username or password.")
            salt = secrets.token_bytes(16)
            con.execute("UPDATE users SET salt=?,password_hash=? WHERE username=?", (salt, password_digest(password, salt), username.strip()))
            con.commit()
        elif not hmac.compare_digest(password_digest(password, salt), stored_hash):
            raise HTTPException(401, "Invalid username or password.")
    finally: con.close()
    request.session.clear(); request.session["user"] = username.strip()
    return {"ok": True, "redirect": "/dashboard"}

@app.post("/api/token/generate")
def token_generate(user=Depends(current_user)):
    token = secrets.token_urlsafe(32)
    with tokens_lock: one_time_tokens[token] = (user, time.time()+TOKEN_TTL_SECONDS)
    return {"ok": True, "token": token, "expires_in": TOKEN_TTL_SECONDS}

@app.post("/api/token/login")
def token_login(request: Request, token: str = Form(...)):
    now = time.time()
    with tokens_lock:
        for k, (_, expiry) in list(one_time_tokens.items()):
            if expiry <= now: one_time_tokens.pop(k, None)
        entry = one_time_tokens.pop(token.strip(), None)
    if not entry or entry[1] <= now: raise HTTPException(401, "Token is invalid, expired or already used.")
    request.session.clear(); request.session["user"] = entry[0]
    return {"ok": True, "redirect": "/dashboard"}



# MSG91 OTP Widget server-side verification.
MSG91_AUTHKEY = os.getenv("MSG91_AUTHKEY", "").strip()
MSG91_VERIFY_URL = "https://control.msg91.com/api/v5/widget/verifyAccessToken"


def _find_verified_identifier(value):
    """Find a verified phone/identifier in MSG91's response."""
    if isinstance(value, dict):
        # MSG91 may return the verified mobile directly in "message".
        message = value.get("message")
        if isinstance(message, (str, int)):
            candidate = str(message).strip()
            if candidate.isdigit():
                return candidate

        for key in ("mobile", "phone", "phone_number", "identifier", "user_id"):
            candidate = value.get(key)
            if isinstance(candidate, (str, int)) and str(candidate).strip():
                return str(candidate).strip()

        for child in value.values():
            found = _find_verified_identifier(child)
            if found:
                return found

    elif isinstance(value, list):
        for child in value:
            found = _find_verified_identifier(child)
            if found:
                return found

    return None


@app.post("/api/msg91/verify")
async def msg91_verify(request: Request):
    if not MSG91_AUTHKEY:
        raise HTTPException(503, "MSG91_AUTHKEY is not configured on the server.")
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid request.")
    access_token = str(payload.get("access_token", "")).strip()
    if not access_token or len(access_token) > 4096:
        raise HTTPException(400, "MSG91 access token is missing or invalid.")

    body = json.dumps({
        "authkey": MSG91_AUTHKEY,
        "access-token": access_token
    }).encode("utf-8")
    req = urllib.request.Request(
        MSG91_VERIFY_URL, data=body,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try: detail = e.read().decode("utf-8")[:500]
        except Exception: detail = "MSG91 verification rejected the token."
        raise HTTPException(401, "MSG91 token verification failed: " + detail)
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        raise HTTPException(502, "Could not contact MSG91 to verify the token.")

    # Temporary diagnostic logging: never log the access token or Auth Key.
    if isinstance(result, dict):
        print(
            "MSG91 verifyAccessToken response:",
            {
                "type": result.get("type"),
                "code": result.get("code"),
                "hasError": result.get("hasError"),
                "message": str(result.get("message", ""))[:200],
            },
            flush=True,
        )
    else:
        print(
            "MSG91 verifyAccessToken response type:",
            type(result).__name__,
            flush=True,
        )

    # Only accept success responses from MSG91.
    if not isinstance(result, dict) or str(result.get("type", "")).lower() not in ("success", "successfully"):
        raise HTTPException(401, "MSG91 did not verify this access token.")

    verified_identifier = _find_verified_identifier(result)
    if not verified_identifier:
        raise HTTPException(401, "MSG91 verified the token but did not return a mobile number.")

    digits = re.sub(r"\D", "", verified_identifier)
    if not digits:
        raise HTTPException(401, "MSG91 returned an invalid verified mobile number.")

    con = db()
    try:
        row = con.execute("SELECT username FROM users WHERE phone_e164=?", (digits,)).fetchone()
    finally:
        con.close()
    if not row:
        raise HTTPException(403, "ACCESS_DENIED: This mobile number is not registered in SKYSCRAPER.")

    request.session.clear()
    request.session["user"] = row["username"]
    return {"ok": True, "redirect": "/dashboard"}

@app.post("/api/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True, "redirect": "/"}

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, user=Depends(current_user)):
    return templates.TemplateResponse(request=request, name="dashboard.html", context={"username": user})

@app.get("/api/about")
def about(request: Request, user=Depends(current_user)):
    con = db()
    try:
        row = con.execute(
            "SELECT username, phone_e164 FROM users WHERE username=?",
            (user,)
        ).fetchone()
    finally:
        con.close()

    if not row:
        raise HTTPException(404, "User account not found.")

    with camera_status_lock:
        camera = camera_status_cache.copy()

    camera_on = mediamtx_running()

    return {
        "owner": OWNER_USERNAME,
        "username": row["username"],
        "phone": row["phone_e164"] or "Not registered",
        "camera_name": camera.get("name") or "Camera",
        "camera_detected": camera.get("detected", False),
        "camera_status": "ON" if camera_on else "OFF"
    }


@app.get("/api/status")
def status(user=Depends(current_user)):
    storage = mount_info()
    with camera_status_lock: camera = camera_status_cache.copy()
    with recording_lock: rec_active, rec_file = recording["active"], recording["file"]
    on = mediamtx_running()
    return {
        "camera_detected": camera["detected"], "camera_status": camera["status"], "camera_name": camera["name"],
        "camera_on": on, "camera_tool": shutil.which("rpicam-hello") or shutil.which("libcamera-hello"),
        "capture_available": on and storage["mounted"],
        "record_available": on and storage["mounted"] and bool(shutil.which("ffmpeg")),
        "storage": storage, "storage_mounted": storage["mounted"],
        "storage_total": storage.get("total"), "storage_used": storage.get("used"), "storage_free": storage.get("free"),
        "recording": rec_active, "recording_file": rec_file,
    }

@app.post("/api/camera/on")
def camera_on(user=Depends(current_user)):
    return start_mediamtx()

@app.post("/api/camera/off")
def camera_off(user=Depends(current_user)):
    stop_recording()
    return stop_mediamtx()

@app.get("/api/camera/inventory")
def camera_inventory(user=Depends(current_user)):
    # Use the existing cached camera detector to avoid probing CSI
    # while MediaMTX may be actively streaming.
    with camera_status_lock:
        camera = camera_status_cache.copy()

    service_running = mediamtx_running()

    paths = {
        "available": False,
        "error": None,
        "items": [],
    }

    # Query only the local MediaMTX API. Do not expose this API externally.
    try:
        api_url = MEDIAMTX_API.rstrip("/") + "/v3/paths/list"
        req = urllib.request.Request(
            api_url,
            headers={"Accept": "application/json"},
        )

        with urllib.request.urlopen(req, timeout=3) as response:
            payload = json.loads(response.read().decode("utf-8"))

        paths["available"] = True

        for item in payload.get("items", []):
            name = item.get("name")
            if name not in ("cam0", "cam1"):
                continue

            tracks = item.get("tracks2") or []
            video_tracks = []

            for track in tracks:
                props = track.get("codecProps") or {}
                video_tracks.append({
                    "codec": track.get("codec"),
                    "width": props.get("width"),
                    "height": props.get("height"),
                    "profile": props.get("profile"),
                    "level": props.get("level"),
                })

            paths["items"].append({
                "name": name,
                "ready": item.get("ready", False),
                "available": item.get("available", False),
                "online": item.get("online", False),
                "source_type": (item.get("source") or {}).get("type"),
                "tracks": item.get("tracks", []),
                "video": video_tracks,
            })

    except urllib.error.HTTPError as exc:
        paths["error"] = f"MediaMTX API HTTP error: {exc.code}"
    except urllib.error.URLError as exc:
        paths["error"] = f"MediaMTX API unavailable: {exc.reason}"
    except (TimeoutError, json.JSONDecodeError, OSError) as exc:
        paths["error"] = f"MediaMTX API query failed: {exc}"

    return {
        "hardware": camera,
        "mediamtx": {
            "running": service_running,
            "api": MEDIAMTX_API,
            "paths": paths,
        },
        "checked_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }


@app.get("/api/camera/status")
def camera_control_status(user=Depends(current_user)):
    return {"running": mediamtx_running()}

@app.get("/api/advanced-settings")
def advanced_settings(user=Depends(current_user)):
    return {"settings": load_advanced_settings(), "clock_sync_options": CLOCK_SYNC_OPTIONS}

@app.put("/api/advanced-settings")
async def advanced_settings_update(request: Request, user=Depends(current_user)):
    try: payload = await request.json()
    except Exception: raise HTTPException(400, "Invalid JSON settings.")
    return {"ok": True, "settings": save_advanced_settings(payload)}

@app.post("/api/capture")
def capture(camera: str = "cam1", user=Depends(current_user)):
    camera_paths = {
        "cam1": "HAWKEYE",
        "cam0": "NV_Cam",
    }

    if camera not in camera_paths:
        raise HTTPException(400, "Invalid camera. Use cam1 or cam0.")

    require_storage()

    if not mediamtx_running():
        raise HTTPException(409, "Turn Camera ON first.")

    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise HTTPException(503, "FFmpeg is not installed.")

    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    require_storage()

    name = (
        "SKY_" + camera_paths[camera] + "_"
        + datetime.now().strftime("%Y%m%d_%H%M%S") + ".jpg"
    )

    dest = safe_child(IMAGE_DIR, name)
    rtsp = f"rtsp://127.0.0.1:8554/{camera}"

    r = run_cmd([
        ffmpeg, "-y", "-rtsp_transport", "tcp",
        "-i", rtsp, "-frames:v", "1", "-q:v", "2", str(dest)
    ], 30)

    if not r or r.returncode or not dest.is_file():
        dest.unlink(missing_ok=True)
        raise HTTPException(
            503, f"{camera_paths[camera]} snapshot failed. Check camera stream and SD card."
        )

    return {"ok": True, "file": name, "camera": camera,
            "camera_name": camera_paths[camera]}


@app.get("/api/media")
def media(user=Depends(current_user)):
    require_storage(); items=[]
    for folder, kind in ((IMAGE_DIR, "image"), (VIDEO_DIR, "video")):
        if folder.exists():
            for p in sorted(folder.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
                try:
                    if p.is_file(): items.append({"name":p.name,"kind":kind,"size":p.stat().st_size,
                        "modified":datetime.fromtimestamp(p.stat().st_mtime).isoformat()})
                except OSError: pass
    return items[:300]

@app.get("/api/media/{kind}/{name}")
def get_media(kind: str, name: str, user=Depends(current_user)):
    require_storage()
    if kind not in ("Images", "Videos"): raise HTTPException(400, "Invalid media category.")
    path=safe_child(MEDIA/kind,name)
    if not path.is_file(): raise HTTPException(404,"File not found.")
    return FileResponse(path)

@app.delete("/api/media/{kind}/{name}")
def delete_media(kind: str, name: str, user=Depends(current_user)):
    require_storage()
    if kind not in ("Images", "Videos"): raise HTTPException(400,"Invalid media category.")
    try: safe_child(MEDIA/kind,name).unlink()
    except FileNotFoundError: raise HTTPException(404,"File not found.")
    return {"ok":True}

@app.post("/api/record/start")
def record_start(camera: str = "cam1", user=Depends(current_user)):
    camera_paths = {
        "cam1": "HAWKEYE",
        "cam0": "NV_Cam",
    }

    if camera == "both":
        cameras = ["cam1", "cam0"]
    elif camera in camera_paths:
        cameras = [camera]
    else:
        raise HTTPException(400, "Choose cam1, cam0, or both.")

    require_storage()

    if not mediamtx_running():
        raise HTTPException(409, "Turn Camera ON first.")

    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise HTTPException(503, "FFmpeg is required for recording.")

    with recording_lock:
        if recording["active"]:
            raise HTTPException(409, "Recording is already active.")

        VIDEO_DIR.mkdir(parents=True, exist_ok=True)
        require_storage()

        processes = []
        names = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        try:
            for cam in cameras:
                name = f"SKY_{camera_paths[cam]}_{timestamp}.mp4"
                dest = safe_child(VIDEO_DIR, name)
                rtsp = f"rtsp://127.0.0.1:8554/{cam}"

                cmd = [
                    ffmpeg, "-nostdin", "-y", "-rtsp_transport", "tcp",
                    "-i", rtsp, "-c", "copy", "-movflags", "+faststart",
                    "-fs", "3500M", str(dest)
                ]

                proc = subprocess.Popen(
                    cmd, stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    start_new_session=True
                )
                processes.append(proc)
                names.append(name)

        except OSError as e:
            for proc in processes:
                if proc.poll() is None:
                    proc.send_signal(signal.SIGINT)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait()
            raise HTTPException(500, f"Could not start recording: {e}")

        recording.update(
            active=True,
            processes=processes,
            files=names,
            file=", ".join(names),
            cameras=cameras,
        )

    camera_name = "Both cameras" if camera == "both" else camera_paths[camera]
    return {
        "ok": True,
        "file": ", ".join(names),
        "files": names,
        "camera": camera,
        "camera_name": camera_name,
    }


@app.post("/api/record/stop")
def record_stop(user=Depends(current_user)):
    return {"ok":True, **(stop_recording() or {"message":"No recording was active."})}


@app.get("/api/stream-info")
def stream_info(request: Request, camera: str = "cam1", user=Depends(current_user)):
    # Only allow the two configured MediaMTX camera paths.
    camera_paths = {
        "cam1": "Night Vision",
        "cam0": "Normal Camera",
    }

    if camera not in camera_paths:
        raise HTTPException(400, "Invalid camera path. Use cam1 or cam0.")

    host = request.headers.get("host", "").split(":")[0]
    scheme = "https" if request.url.scheme == "https" else "http"

    url = f"{scheme}://{host}:{MEDIAMTX_WEBRTC_PORT}/{camera}"

    return {
        "configured": True,
        "url": url,
        "path": camera,
        "name": camera_paths[camera],
        "note": "MediaMTX WebRTC player",
    }

