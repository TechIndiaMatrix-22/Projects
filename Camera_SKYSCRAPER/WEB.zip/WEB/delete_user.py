import sqlite3
import sys

if len(sys.argv) != 2:
    print("Usage: python3 delete_user.py DATABASE_PATH")
    sys.exit(1)

conn = sqlite3.connect(sys.argv[1])

try:
    users = conn.execute(
        "SELECT id, username FROM users"
    ).fetchall()

    print("\nRegistered users:")
    for uid, username in users:
        print(f"ID: {uid} | Username: {username}")

    username = input("\nEnter username to delete: ").strip()

    row = conn.execute(
        "SELECT id FROM users WHERE username=?",
        (username,)
    ).fetchone()

    if not row:
        print("User not found.")
        sys.exit(1)

    confirm = input(
        f"Type DELETE {username} to confirm: "
    )

    if confirm != f"DELETE {username}":
        print("Deletion cancelled.")
        sys.exit(0)

    conn.execute("BEGIN")

    conn.execute(
        "DELETE FROM tokens WHERE username=?",
        (username,)
    )

    cursor = conn.execute(
        "DELETE FROM users WHERE username=?",
        (username,)
    )

    if cursor.rowcount == 0:
        raise RuntimeError("User deletion failed.")

    conn.execute("""
        CREATE TABLE IF NOT EXISTS dashboard_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            username TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute(
        "INSERT INTO dashboard_events (event_type, username) VALUES (?, ?)",
        ("user_deleted", username)
    )

    conn.commit()

    print(f"\nUser '{username}' and associated tokens deleted successfully.")

except Exception as e:
    conn.rollback()
    print(f"ERROR: {e}")
    sys.exit(1)

finally:
    conn.close()
