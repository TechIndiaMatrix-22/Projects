# SKYSCRAPER — WEB deployment (application on eMMC, media on removable SD)

## Required layout

Application project (on Raspberry Pi eMMC/home filesystem):
`/home/xdtpi1/Desktop/Projects/WEB/skyscraper/`

Captured media only (on removable SD):
- `/media/camera_sd/Images/`
- `/media/camera_sd/Videos/`
- `/media/camera_sd/Thumbnails/`

The Python virtual environment, SQLite user database, HTTPS certificate/private key, OS and application source stay on eMMC. The removable card stores captured images/videos and thumbnails only.

## Boot behaviour

The `skyscraper.service` starts at every boot even if the SD card is absent. The dashboard can therefore be opened without the card and displays a red SD-missing warning. Capture, recording, media listing, download and delete APIs check the real mounted filesystem and return HTTP 503 if it is unavailable. The dashboard refreshes storage state every 2 seconds.

When the card is present during setup, `setup.sh` records its filesystem UUID and configures `/etc/fstab` with `nofail`, plus a udev rule to request the generated mount unit when that card is inserted. This allows the web application to remain up while the card is absent. If the card is inserted after boot, udev requests the mount unit; the app detects it on the next status poll.

## Install

1. Extract the ZIP so its `app`, `web`, `requirements.txt`, `skyscraper.service`, and `setup.sh` are directly inside:
   `/home/xdtpi1/Desktop/Projects/WEB/skyscraper/`
2. If the removable card is currently inserted, ensure it is mounted at `/media/camera_sd`.
3. Run:
   ```bash
   cd ~/Desktop/Projects/WEB/skyscraper
   chmod +x setup.sh
   ./setup.sh
   ```
4. Check:
   ```bash
   sudo systemctl status skyscraper --no-pager
   curl -k -i https://127.0.0.1:8000/
   ```
5. From Windows, open `https://<Pi-IP>:8000`.

## SD mount setup and safety

- Do not format the card as part of this setup.
- Keep a UUID-based `/etc/fstab` mount entry for `/media/camera_sd` with `nofail`.
- If the card is absent during setup, install still proceeds and the app starts, but the expected UUID must be configured when the card is next mounted. Rerun `./setup.sh` with the card mounted to capture its UUID and create the udev mount rule.
- Never remove the card during active recording. The application attempts to stop recording if storage disappears, but sudden physical removal can corrupt the current video file.
- A FAT32 card has a maximum single-file size of 4 GiB. The recorder's configured cap is below this limit; production-grade automatic segmented recording still requires a dedicated rotation test.

## Functional scope and limitations

Login/registration, one-time access tokens, HTTPS, SD status polling, photo capture, video recording and media listing/download/delete are implemented. Camera commands must be installed and the OV5647 camera must be available. Browser live view requires a working MediaMTX HLS/WebRTC browser URL and a compatible player integration. Night-vision GPIO/IR-cut control is deliberately not activated until the actual circuit and GPIO pin are verified. Registration remains open; keep this system on a trusted LAN until registration restrictions and additional security hardening are added.
