#!/bin/bash
# SKYSCRAPER removable SD-card status checker
# Usage: ./check_sd.sh

MOUNT_POINT="/media/camera_sd"
EXPECTED_UUID="0303-19DB"

printf '\n==============================================\n'
printf '          SKYSCRAPER SD CARD STATUS\n'
printf '==============================================\n'

if mountpoint -q "$MOUNT_POINT"; then
    SOURCE="$(findmnt -rn -M "$MOUNT_POINT" -o SOURCE | head -n1)"
    FSTYPE="$(findmnt -rn -M "$MOUNT_POINT" -o FSTYPE | head -n1)"
    UUID="$(findmnt -rn -M "$MOUNT_POINT" -o UUID | head -n1)"

    if [ "$UUID" = "$EXPECTED_UUID" ]; then
        printf 'STATUS       : SD CARD MOUNTED (EXPECTED CARD)\n'
    else
        printf 'STATUS       : A FILESYSTEM IS MOUNTED (CHECK UUID)\n'
    fi
    printf 'DEVICE       : %s\n' "${SOURCE:-Unknown}"
    printf 'FILESYSTEM   : %s\n' "${FSTYPE:-Unknown}"
    printf 'UUID         : %s\n' "${UUID:-Unavailable}"
    printf 'MOUNT POINT  : %s\n' "$MOUNT_POINT"

    printf '\nSTORAGE CAPACITY:\n'
    df -h "$MOUNT_POINT" | awk 'NR==1 {print} NR==2 {printf "%-16s %-7s %-7s %-7s %-6s %s\n", $1, $2, $3, $4, $5, $6}'

    printf '\nDIRECTORIES:\n'
    for dir in Images Videos Thumbnails; do
        if [ -d "$MOUNT_POINT/$dir" ]; then
            printf '  [OK]      %s\n' "$dir"
        else
            printf '  [MISSING] %s\n' "$dir"
        fi
    done
else
    printf 'STATUS       : SD CARD NOT MOUNTED\n'
    printf 'MOUNT POINT  : %s\n' "$MOUNT_POINT"
    printf '\nCONNECTED BLOCK DEVICES:\n'
    if command -v lsblk >/dev/null 2>&1; then
        lsblk -o NAME,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINTS
    else
        echo 'lsblk command not available.'
    fi
    printf '\nNo storage capacity is shown because the SD card is not mounted.\n'
fi

printf '==============================================\n\n'
