#!/bin/bash
set -euo pipefail

PROJECT="/home/xdtpi1/Desktop/Projects/WEB"
MOUNT="/media/camera_sd"
VENV="/home/xdtpi1/.venvs/skyscraper"
DBDIR="/home/xdtpi1/.local/share/skyscraper"

if [ ! -f "$PROJECT/app/main.py" ]; then
  echo "ERROR: Project files not found at $PROJECT"
  echo "Extract the project ZIP so app/, web/ and requirements.txt are directly inside this folder."
  exit 1
fi

sudo apt update
sudo apt install -y python3-venv openssl ffmpeg

mkdir -p /home/xdtpi1/.venvs "$DBDIR"
chmod 700 "$DBDIR"
if [ ! -x "$VENV/bin/python" ]; then
  python3 -m venv "$VENV"
fi
"$VENV/bin/pip" install --upgrade pip
"$VENV/bin/pip" install -r "$PROJECT/requirements.txt"

sudo mkdir -p /etc/skyscraper/tls "$MOUNT"
if [ ! -f /etc/skyscraper.env ]; then
  sudo sh -c 'umask 077; printf "SKYSCRAPER_SECRET=%s\n" "$(python3 -c "import secrets; print(secrets.token_urlsafe(48))")" > /etc/skyscraper.env'
fi

# Configure SD UUID only if the card is mounted right now.
# If absent, app still starts; media functions remain disabled until the card is mounted.
if mountpoint -q "$MOUNT"; then
  UUID="$(findmnt -rn -M "$MOUNT" -o UUID | head -n1)"
  if [ -n "$UUID" ]; then
    sudo sed -i '/^SKYSCRAPER_SD_UUID=/d' /etc/skyscraper.env
    echo "SKYSCRAPER_SD_UUID=$UUID" | sudo tee -a /etc/skyscraper.env >/dev/null

    # Keep the existing UUID entry if present; otherwise add a nofail entry.
    if ! grep -qE "^[^#].*[[:space:]]${MOUNT//\//\\/}[[:space:]]" /etc/fstab; then
      echo "UUID=$UUID  $MOUNT  vfat  defaults,nofail,x-systemd.device-timeout=10s,uid=1000,gid=1000,umask=0022  0  0" | sudo tee -a /etc/fstab >/dev/null
    fi

    # On insertion, request the generated systemd mount unit for this UUID.
    sudo tee /etc/udev/rules.d/90-skyscraper-sd.rules >/dev/null <<EOF
ACTION=="add", SUBSYSTEM=="block", ENV{ID_FS_UUID}=="$UUID", TAG+="systemd", ENV{SYSTEMD_WANTS}+="media-camera_sd.mount"
EOF
    sudo udevadm control --reload-rules
  else
    echo "WARNING: SD card mounted but filesystem UUID could not be read."
  fi
else
  echo "NOTE: SD card is not mounted now. SKYSCRAPER will still start; media features stay disabled."
  echo "Insert/mount the card later, then configure its UUID in /etc/skyscraper.env if not already configured."
fi

# Create a self-signed HTTPS certificate if none exists.
if [ ! -s /etc/skyscraper/tls/server.crt ] || [ ! -s /etc/skyscraper/tls/server.key ]; then
  PI_IP="$(hostname -I | awk '{print $1}')"
  sudo openssl req -x509 -nodes -days 825 -newkey rsa:3072 \
    -keyout /etc/skyscraper/tls/server.key \
    -out /etc/skyscraper/tls/server.crt \
    -subj "/CN=skyscraper.local" \
    -addext "subjectAltName=DNS:skyscraper.local,IP:${PI_IP},IP:127.0.0.1"
fi
sudo chown root:xdtpi1 /etc/skyscraper/tls
sudo chmod 750 /etc/skyscraper/tls
sudo chown root:xdtpi1 /etc/skyscraper/tls/server.key
sudo chmod 640 /etc/skyscraper/tls/server.key
sudo chmod 644 /etc/skyscraper/tls/server.crt

sudo cp "$PROJECT/skyscraper.service" /etc/systemd/system/skyscraper.service
sudo systemctl daemon-reload
sudo systemctl enable skyscraper.service
sudo systemctl restart skyscraper.service

echo
echo "SKYSCRAPER installed and enabled at boot."
echo "Project: $PROJECT"
echo "Media target: $MOUNT (removable SD only)"
echo "Check: sudo systemctl status skyscraper --no-pager"
echo "Test: curl -k -i https://127.0.0.1:8000/"
