#!/bin/bash
set -eu
MOUNT="/media/camera_sd"
while ! mountpoint -q "$MOUNT"; do
  sleep 2
done
