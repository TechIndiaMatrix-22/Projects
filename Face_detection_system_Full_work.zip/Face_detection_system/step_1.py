import face_recognition
import dlib

print("face_recognition ✅")
print("dlib version:", dlib.__version__)