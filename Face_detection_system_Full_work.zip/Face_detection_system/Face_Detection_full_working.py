import cv2
import face_recognition
import os
import numpy as np

# =========================
# LOAD KNOWN FACES
# =========================
known_encodings = []
known_names = []

base_path = "Known_faces"

for person_name in os.listdir(base_path):
    person_path = os.path.join(base_path, person_name)

    if os.path.isdir(person_path):
        for file in os.listdir(person_path):
            img_path = os.path.join(person_path, file)

            image = face_recognition.load_image_file(img_path)
            encodings = face_recognition.face_encodings(image)

            if len(encodings) > 0:
                known_encodings.append(encodings[0])
                known_names.append(person_name.lower())

print("✅ Loaded:", set(known_names))


# =========================
# START CAMERA
# =========================
cap = cv2.VideoCapture(0)

frame_count = 0
face_locations = []
face_names = []

while True:
    ret, frame = cap.read()

    if not ret:
        print("❌ Camera error")
        break

    # 🔥 Better quality for laptop
    small_frame = cv2.resize(frame, (480, 360))

    rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    frame_count += 1

    # 🔥 Run recognition every 2 frames (smooth on laptop)
    if frame_count % 2 == 0:

        face_locations = face_recognition.face_locations(rgb_small)
        face_encodings = face_recognition.face_encodings(
            rgb_small, face_locations, model="small"
        )

        face_names = []

        for encoding in face_encodings:

            face_distances = face_recognition.face_distance(
                known_encodings, encoding
            )

            name = "Unknown"

            if len(face_distances) > 0:
                best_index = np.argmin(face_distances)
                best_distance = face_distances[best_index]

                print("Distance:", best_distance)

                # 🔥 Strict threshold (no false positives)
                if best_distance < 0.38:
                    name = known_names[best_index]

            face_names.append(name)

    # =========================
    # DRAW RESULTS
    # =========================
    for (top, right, bottom, left), name in zip(face_locations, face_names):

        # Scale back to original frame size
        top = int(top * frame.shape[0] / 360)
        right = int(right * frame.shape[1] / 480)
        bottom = int(bottom * frame.shape[0] / 360)
        left = int(left * frame.shape[1] / 480)

        cv2.rectangle(frame, (left, top), (right, bottom), (0,255,0), 2)

        cv2.putText(frame, name,
                    (left, top - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.9,
                    (0,255,0),
                    2)

    cv2.imshow("Face Recognition (Laptop)", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()