import cv2
import face_recognition

img = cv2.imread("Known_faces/VINCY/Vincy (1).jpeg")
rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

faces = face_recognition.face_locations(rgb)

print("Faces detected:", len(faces))